
Modern Full Stack ECommerce Application with Stripe & Sanity


A Full Stack Ecommerce application with Payments functionality. With Modern design, animations, the ability to add and edit products on the go using a CMS, all advanced cart functionalities, and the complete integration with Stripe so that you can cover REAL payments. 

If Sanity doesn’t install or run on Windows, try:

Run in PowerShell:
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned

Delete node_modules and package-lock.json, then run npm install again.

Make sure Sanity CLI is installed:
npm install -g @sanity/cli
